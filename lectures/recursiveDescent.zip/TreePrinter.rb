# TreePrinter: used for printing a text representation of a parse tree
class TreePrinter
	class Item
		attr_reader :node, :remaining

		def initialize(node)
			@node = node
			@remaining = node.children().length
			@visited = false
		end

		def visited?
			return @visited
		end

		def set_visited
			@visited = true
		end

		def next_child
			raise "No more children" if @remaining == 0
			children = @node.children()
			child = children[children.length - @remaining]
			@remaining -= 1
			return child
		end
	end

	def initialize
		@stack = []
	end

	def print(node)
		@stack.push(Item.new(node))

		while !@stack.empty?
			item = @stack.pop()
			if !item.visited?
				_print_node(item.node())
				item.set_visited()
			end
			if item.remaining() > 0
				@stack.push(item)
				@stack.push(Item.new(item.next_child()))
			end
		end
	end

	def _print_node(node)
		(0 .. @stack.length-1).each do |i|
			parent_level = (i == @stack.length - 1)
			Kernel::print parent_level ? "+--" : (@stack[i].remaining > 0 ? "|  " : "   ")
		end
		Kernel::print node.type()
		Kernel::print "(\"#{node.value()}\")" if !node.value().nil?
		Kernel::print "\n"
	end
end
