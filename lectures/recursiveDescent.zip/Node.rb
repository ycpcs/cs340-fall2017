# Parse tree node
class Node
	attr_reader :type, :value, :children

	def initialize(type, *args)
		@type = type
		@value = args[0] if args.length > 0
		@children = []
	end

	# Make a terminal node from a token
	def self.terminal(t)
		return Node.new(t.type(), t.lexeme())
	end

	# Make a nonterminal node
	def self.nonterminal(type)
		return Node.new(type)
	end

	def add_child(child)
		@children.push(child)
	end
end
