#! /usr/bin/ruby

require './Token.rb'
require './Lexer.rb'
require './Node.rb'
require './TreePrinter.rb'

# Parser class
class Parser
	def initialize(lexer)
		@lexer = lexer
	end

	def parse
		return parseS()
	end

	def parseS
		n = Node::nonterminal(:S)
		n.add_child(parseE())
		return n
	end

	def parseE
		# E -> T E'
		n = Node::nonterminal(:E)
		n.add_child(parseT())
		n.add_child(parseEPrime())
		return n
	end

	def parseEPrime
		n = Node::nonterminal(:EPrime)
		t = @lexer.peek()
		if !t.nil? && (t.type() == :op_plus || t.type() == :op_minus)
			# E' -> + T E'
			# E' -> - T E'
			t = @lexer.next()
			n.add_child(Node::terminal(t))
			n.add_child(parseT())
			n.add_child(parseEPrime())
		else
			# E' -> epsilon
		end

		return n
	end

	def parseT
		# T -> F T'
		n = Node::nonterminal(:T)
		n.add_child(parseF())
		n.add_child(parseTPrime())
		return n
	end

	def parseTPrime
		n = Node::nonterminal(:TPrime)
		t = @lexer.peek()
		if !t.nil? && (t.type() == :op_mul || t.type() == :op_div)
			# T' -> * F T'
			# T' -> / F T'
			t = @lexer.next()
			n.add_child(Node::terminal(t))
			n.add_child(parseF())
			n.add_child(parseTPrime())
		else
			# T' -> epsilon
		end

		return n
	end

	def parseF
		n = Node::nonterminal(:F)
		t = @lexer.next()
		if t.type() == :num || t.type() == :var
			# F -> var
			# F -> num
			n.add_child(Node::terminal(t))
		else
			raise "Syntax error: saw #{t.type()}, expected var or num"
		end
		return n
	end
end

# Main program: read input from stdin and parse it

lexer = Lexer.new(STDIN)
parser = Parser.new(lexer)

tree = parser.parse()

tp = TreePrinter.new()
tp.print(tree)

# vim: tabstop=4
