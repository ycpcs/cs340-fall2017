# Token class
class Token
	attr_reader :type, :lexeme

	def initialize(type, lexeme)
		@type = type
		@lexeme = lexeme
	end
end
