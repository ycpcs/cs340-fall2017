(ns clojure-mandelbrot.core-test
  (:require [clojure.test :refer :all]
            [clojure-mandelbrot.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
