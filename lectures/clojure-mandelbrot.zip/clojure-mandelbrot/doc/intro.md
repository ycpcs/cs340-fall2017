# Introduction to clojure-mandelbrot

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
