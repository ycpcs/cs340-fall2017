(ns clojure-mandelbrot.rowagent
  (require [clojure-mandelbrot.mandelbrot :as m]))

; A row agent's data is a vector
;    [receiver sendrow]
; indicating the agent to which results should be sent (receiver)
; and the message function to be used to send the results back.

; Create a row agent.
;
; Params:
;    receiver - the mandelbrot agent to which row results should be sent
;    sendrow - the message function to be used to send each row result
(defn create [receiver sendrow]
;  (println "starting row agent")
  (agent [receiver sendrow]))

; Message function to request a computation for one row.
(defn compute-row [[receiver sendrow] [id row y xstart xinc ncols]]
;  (println "Computing row: "  [row y xstart xinc ncols])
  ; Do the computation for this row.
  (let [iters (m/compute-row y xstart xinc ncols)]
    ; Send the results for this row back to the receiver
    ; (the mandelbrot agent.)
    (send receiver sendrow [id row iters])
    ; Row agent's data does not change.
    [receiver sendrow]))
