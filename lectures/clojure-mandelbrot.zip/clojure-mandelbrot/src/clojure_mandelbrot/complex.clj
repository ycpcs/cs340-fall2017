(ns clojure-mandelbrot.complex)

(defn create [real imag]
  [(double real) (double imag)])

(defn add [[a b] [c d]]
  [(+ a c) (+ b d)])

(defn mul [[a b] [c d]]
  [(- (* a c) (* b d)) (+ (* b c) (* a d))])

(defn magnitude [[a b]]
  (Math/sqrt (+ (* a a) (* b b))))
