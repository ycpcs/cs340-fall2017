(ns clojure-mandelbrot.mandelbrotagent
  (require [clojure-mandelbrot.rowagent :as rowagent]))

; The data for the mandelbrot agent is a map of
; unique ids (generated symbols) to vectors containing
;     [nrows row-data]
; When results for one row are received, the unique id indicates
; which vector's row data should be updated.

(defn create []
  ; Initial data:
  ;   nprocs - how many processes to create when the computation starts
  ;   0 - number of rows computed so far
  ;   [] - initial accumulator for computed rows
  (agent {}))

; Message function used by the row agents to send one row result
; back to the mandelbrot agent.
(defn row-result [data [id row iters]]
  ; Find the vector for the computation named by id
  (let [[nrows row-data] (get data id)
        ; TODO: render result if row-data is complete (has as many rows as nrows)
         updated-row-data (conj row-data [row iters])]
        (if (= (count updated-row-data) nrows)
          (do
            (println "Final data:")
            (println updated-row-data)))
        (assoc data id [nrows updated-row-data])))

; Message function to start a computation.
; Creates agents and assigns work to them.
(defn start [data [x1 y1 x2 y2 nrows ncols nprocs]]
  (let [xinc (/ (- x2 x1) ncols)
        yinc (/ (- y2 y1) nrows)
        ; create as many agents as nprocs specifies
        agents (mapv (fn [x] (rowagent/create *agent* row-result)) (range nprocs))
        ; create a unique id for this computation
        id (gensym)]
    ; send work to row agents
    (doall
      (for [row (range nrows)]
        (do
          (let [y (+ y1 (* row yinc))]
;            (println "Sending row " y " to agent " (mod row nprocs))
            (send (nth agents (mod row nprocs)) rowagent/compute-row [id row y x1 xinc ncols]))
          )
        )
    )
    ; Add an entry to the mandelbrot agent's data in which to
    ; receive the row results from the row agents.
    (assoc data id [nrows []])
    ))
