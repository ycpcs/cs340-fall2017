(ns clojure-mandelbrot.mandelbrot
  (require [clojure-mandelbrot.complex :as complex]))

(def MAX 1000)

(defn compute-iters [c]
  (loop [iters 0
         z (complex/create 0 0)]
    (if (or (>= iters MAX) (> (complex/magnitude z) 2.0))
      iters
      (recur (inc iters) (complex/add (complex/mul z z) c)))))

(defn compute-row [y xstart xinc ncols]
  (let [cvals (map (fn [i] (complex/create (+ xstart (* i xinc)) y)) (range 0 ncols))]
    (map compute-iters cvals)))
