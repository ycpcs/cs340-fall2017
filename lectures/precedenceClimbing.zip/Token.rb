# Token class
class Token
	def initialize(type, lexeme)
		@type = type
		@lexeme = lexeme
	end

	def get_type
		return @type
	end

	def get_lexeme
		return @lexeme
	end
end
