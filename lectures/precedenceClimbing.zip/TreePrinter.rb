# TreePrinter: used for printing a text representation of a parse tree
class TreePrinter
	class Item
		def initialize(node)
			@node = node
			@remaining = node.get_children().length
			@visited = false
		end

		def get_node
			return @node
		end

		def get_remaining
			return @remaining
		end

		def visited?
			return @visited
		end

		def set_visited
			@visited = true
		end

		def next_child
			raise "No more children" if @remaining == 0
			children = @node.get_children()
			child = children[children.length - @remaining]
			@remaining -= 1
			return child
		end
	end

	def initialize
		@stack = []
	end

	def print(node)
		@stack.push(Item.new(node))

		while !@stack.empty?
			item = @stack.pop()
			if !item.visited?
				_print_node(item.get_node())
				item.set_visited()
			end
			if item.get_remaining() > 0
				@stack.push(item)
				@stack.push(Item.new(item.next_child()))
			end
		end
	end

	def _print_node(node)
		(0 .. @stack.length-1).each do |i|
			parent_level = (i == @stack.length - 1)
			Kernel::print parent_level ? "+--" : (@stack[i].get_remaining > 0 ? "|  " : "   ")
		end
		Kernel::print node.get_type()
		Kernel::print "(\"#{node.get_value()}\")" if !node.get_value().nil?
		Kernel::print "\n"
	end
end
