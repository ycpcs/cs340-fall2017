#! /usr/bin/ruby

require 'Token.rb'
require 'Lexer.rb'
require 'Node.rb'
require 'TreePrinter.rb'

# Parser class
class Parser
	def initialize(lexer)
		@lexer = lexer
	end

	def parse
		return _parse_1(_parse_primary(), 0)
	end

	def _parse_1(lhs, min_prec)
		# while the next token is a binary operator whose precedence is >= min_precedence
		while true
			op = @lexer.peek()
			break if op.nil? or !_is_operator(op) or _prec(op) < min_prec
			@lexer.next()
			rhs = _parse_primary()

			# while the next token is
			#   (1) a binary operator whose precedence is greater than op's, or
			#   (2) a right-associative operator whose precedence is equal to op's
			while true
				lookahead = @lexer.peek()
				break if (lookahead.nil? or
					!_is_operator(lookahead) or
					!(_prec(lookahead) > _prec(op) or
					  (_assoc(lookahead) == :right and _prec(lookahead) == _prec(op))))
				rhs = _parse_1(rhs, _prec(lookahead))
			end

			n = Node::nonterminal(op.get_type())
			n.add_child(lhs)
			n.add_child(rhs)
			lhs = n
		end

		return lhs
	end

	# Determine whether given token is an operator
	def _is_operator(t)
		case t.get_type()
		when :op_plus, :op_minus, :op_mul, :op_div
			return true
		else
			return false
		end
	end

	# Get precedence of given operator
	def _prec(op)
		case op.get_type()
		when :op_plus, :op_minus
			return 0
		when :op_mul, :op_div
			return 1
		end
	end

	# Get associativity of given operator
	def _assoc(op)
		case op.get_type()
		when :op_plus, :op_minus, :op_mul, :op_div
			return :left
		end
	end

	def _parse_primary
		n = Node::nonterminal(:primary)
		# In our grammar, the primary expressions are variables and numbers
		t = @lexer.next()
		raise "Invalid primary expression #{t.get_lexeme()}" if !(t.get_type() == :var or t.get_type() == :num)
		n.add_child(Node::terminal(t))
		return n
	end
end

# Main program: read input from stdin and parse it

lexer = Lexer.new(STDIN)
parser = Parser.new(lexer)

tree = parser.parse()

tp = TreePrinter.new()
tp.print(tree)

# vim: tabstop=4
