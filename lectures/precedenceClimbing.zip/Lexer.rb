# Lexical analyzer class
class Lexer
	def initialize(f)
		@f = f
		@line = nil
		@t = nil
		@eof = false
	end

	PATTERNS = [
		[/^[a-z]+/, :var],
		[/^[0-9]+/, :num],
		[/^\+/, :op_plus],
		[/^-/, :op_minus],
		[/^\*/, :op_mul],
		[/^\//, :op_div],
	]

	# Read and consume next token
	def next
		_fill()
		raise "Unexpected end of input" if @t.nil?
		tok, @t = @t, nil
		return tok
	end

	# Return next token without consuming it
	def peek
		_fill()
		return @t
	end

	# Read one token, saving it in @t
	def _fill
		return if @eof || !@t.nil?

		# read a line of input
		while @line.nil? || @line.lstrip() == ''
			@line = @f.gets()
			if @line.nil?  # end of file?
				@eof = true
				return
			end
		end

		@line.lstrip!

		# Try all of the patterns
		PATTERNS.each do |pat|
			if m = pat[0].match(@line)
				# Found a match!
				@t = Token.new(pat[1], m[0])
				@line = m.post_match().lstrip()
				return
			end
		end

		# None of the patterns matched
		raise "Unrecognized token: #{@line}"
	end
end
