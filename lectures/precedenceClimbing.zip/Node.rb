# Parse tree node
class Node
	def initialize(type, *args)
		@type = type
		@value = args[0] if args.length > 0
		@children = []
	end

	# Make a terminal node from a token
	def self.terminal(t)
		return Node.new(t.get_type(), t.get_lexeme())
	end

	# Make a nonterminal node
	def self.nonterminal(type)
		return Node.new(type)
	end

	def add_child(child)
		@children.push(child)
	end

	def get_children
		return @children
	end

	def get_type
		return @type
	end

	def get_value
		return @value
	end
end
