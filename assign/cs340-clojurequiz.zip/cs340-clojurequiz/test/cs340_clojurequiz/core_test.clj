(ns cs340-clojurequiz.core-test
  (:require [clojure.test :refer :all]
            [cs340-clojurequiz.core :refer :all]))

(deftest swap-maybe-test
  (testing "swap-maybe"
    (is (= [4 5] (swap-maybe [4 5])))
    (is (= [4 5] (swap-maybe [5 4])))
    (is (= [-10 2] (swap-maybe [2 -10])))
    ))

(deftest negate-all-test
  (testing "negate-all"
    (is (= [-1 -2 -3] (negate-all [1 2 3])))
    (is (= [5 -3 -14 6 -2 -79] (negate-all [-5 3 14 -6 2 79])))
    (is (= [-7 -29 11 -4 -8 17] (negate-all [7 29 -11 4 8 -17])))
    ))

(deftest rotate1-test
  (testing "rotate1"
    (is (= [:b :c :a] (rotate1 [:a :b :c])))
    (is (= ["and" "beans" "for" "dinner" "ham"] (rotate1 ["ham" "and" "beans" "for" "dinner"])))
    (is (= [2 3 4 5 6 7 1] (rotate1 [1 2 3 4 5 6 7])))
    ))

(deftest rotaten-test
 (testing "rotaten"
   (is (= [:a :b :c] (rotaten [:a :b :c] 0)))
   (is (= [:b :c :a] (rotaten [:a :b :c] 1)))
   (is (= [:c :a :b] (rotaten [:a :b :c] 2)))
   (is (= [:a :b :c] (rotaten [:a :b :c] 3)))
   ))
