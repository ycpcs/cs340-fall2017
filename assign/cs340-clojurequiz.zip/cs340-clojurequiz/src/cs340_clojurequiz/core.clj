(ns cs340-clojurequiz.core)

;; Given a two-element vector, determine whether the two members
;; are in order using the < function.  If they are in order
;; (i.e., the first element is less than the second),
;; return the original vector.  Otherwise, return a vector in
;; which the two members are swapped.
;;
;; Parameters:
;;    v - a two-element vector
;;
;; Returns:
;;    a vector with the members of v in the correct order
;;
;; Examples:
;;    (swap-maybe [4 5]) => [4 5]
;;    (swap-maybe [5 4]) => [4 5]
;;    (swap-maybe [2 -10]) => [-10 2]
;;
;; Hints:
;;    - (< a b) returns true if a is less than b, false otherwise
;;    - destructuring the vector will be useful
;;
(defn swap-maybe [v]
  "OHAI!")


;; Negate (multiply by -1) all of the numbers in the
;; specified sequence, returning the resulting sequence.
;;
;; Parameters:
;;    s - a sequence of numbers
;;
;; Returns:
;;    a sequence containing the negated values of s
;;
;; Examples:
;;    (negate-all [1 2 3]) => [-1 -2 -3]
;;    (negate-all [-5 3 14 -6 2 79]) => [5 -3 -14 6 -2 -79]
;;
;; Hints/specifications:
;;   - use tail recursion
;;   - loop/recur will be easier than writing an explicit helper function
;;   - you will need an accumulator (for the resulting sequence)
;;
(defn negate-all [s]
  "OHAI!")


;; Rotate the given vector one position so that the
;; first element becomes the last element of the result.
;;
;; Parameters:
;;    v - a nonempty vector
;;
;; Returns:
;;    a vector with the elements of the original vector, such
;;    that the original first element becomes the new last
;;    element, and the order of the other elements does not
;;    change
;;
;; Examples:
;;    (rotate1 [:a :b :c]) => [:b :c :a]
;;    (rotate1 ["ham" "and" "beans" "for" "dinner"])
;;       ["and" "beans" "for" "dinner" "ham"]
;;
;; Hints:
;;    Note that (rest v) does not return a vector.  You can
;;    get a vector with all but the first elements of v
;;    using (subvec v 1).
;;
(defn rotate1 [v]
  "OHAI!")


;; Use recursion to invoke the rotate1 function a specified
;; number of times on the given vector.
;;
;; Parameters:
;;    v - a vector
;;    n - the number of times to invoke rotate1 on v
;;
;; Returns:
;;    the result of invoking rotate1 n times on the vector v
;;
;; Examples:
;;    (rotaten [:a :b :c] 0) => [:a :b :c]
;;    (rotaten [:a :b :c] 1) => [:b :c :a]
;;    (rotaten [:a :b :c] 2) => [:c :a :b]
;;    (rotaten [:a :b :c] 3) => [:a :b :c]
;;
;; Hints:
;;    * use tail recursion (use recur to make the recursive call)
;;    * you won't need an accumulator
;;    * the recursion should be on n (the number of times to rotate)
;;    * the base case should occur when the number of times
;;      to rotate is 0
;;
(defn rotaten [v n]
  "KTHXBYE!")
