(ns cs340-exam02.core-test
  (:require [clojure.test :refer :all]
            [cs340-exam02.core :refer :all]))

;;    (juggle [:a :b :c] 0) => [:b :a :c]
;;    (juggle [:b :a :c] 1) => [:b :c :a]
;;    (juggle [:b :c :a] 2) => [:c :b :a]
;;    (juggle [:c :b :a] 3) => [:c :a :b]
;;    (juggle ["red" "green" "blue"] 49) => ["red" "blue" "green"]
(deftest juggle-test
  (testing "juggle"
    (is (= [:b :a :c] (juggle [:a :b :c] 0)))
    (is (= [:b :c :a] (juggle [:b :a :c] 1)))
    (is (= [:c :b :a] (juggle [:b :c :a] 2)))
    (is (= [:c :a :b] (juggle [:c :b :a] 3)))
    (is (= ["red" "blue" "green"] (juggle ["red" "green" "blue"] 49)))
    ))


;;    (generate-multiples 3 4) => [3 6 9 12]
;;    (generate-multiples 2 10) => [2 4 6 8 10 12 14 16 18 20]
;;    (generate-multiples 5 1) => [5]
;;    (generate-multiples 11 5) => [11 22 33 44 55]
;;    (generate-multiples -4 5) => [-4 -8 -12 -16 -20]
;;    (generate-multiples 9 0) => []
(deftest generate-multiples-test
  (testing "generate-multiples"
    (is (= [3 6 9 12] (generate-multiples 3 4)))
    (is (= [2 4 6 8 10 12 14 16 18 20] (generate-multiples 2 10)))
    (is (= [5] (generate-multiples 5 1)))
    (is (= [11 22 33 44 55] (generate-multiples 11 5)))
    (is (= [-4 -8 -12 -16 -20] (generate-multiples -4 5)))
    (is (= [] (generate-multiples 9 0)))
    ))

;;    ((make-multi-applicator list 4) :a) => (:a :a :a :a)
;;    ((make-multi-applicator vector 4) :a) => [:a :a :a :a]
;;    ((make-multi-applicator + 3) 2) => 6
;;    ((make-multi-applicator * 3) 2) => 8
(deftest make-multi-applicator-test
  (testing "make-multi-applicator"
    (is (= '(:a :a :a :a) ((make-multi-applicator list 4) :a)))
    (is (= [:a :a :a :a] ((make-multi-applicator vector 4) :a)))
    (is (= 6 ((make-multi-applicator + 3) 2)))
    (is (= 8 ((make-multi-applicator * 3) 2)))
    ))


;;    (count-matching even? [1 2 3 4 5]) => 2
;;    (count-matching (fn [x] (= x :spam)) [:spam :spam :eggs :spam :baked-beans :spam :spam])
;;       => 5
;;    (count-matching sequential? [:a :b [:c] :d [:e :f] '(:g)]) => 3
(deftest count-matching-test
  (testing "count-matching"
    (is (= 2 (count-matching even? [1 2 3 4 5])))
    (is (= 5 (count-matching (fn [x] (= x :spam)) [:spam :spam :eggs :spam :baked-beans :spam :spam])))
    (is (= 3 (count-matching sequential? [:a :b [:c] :d [:e :f] '(:g)])))
    ))


;;    (apply-fn-chain [] 4) => 4
;;    (apply-fn-chain [inc inc (fn [x] (* x 2))] 4) => 12
;;    (apply-fn-chain [reverse list] [:a :b :c]) => ((:c :b :a))
;;    (apply-fn-chain [count (fn [x] (* x 10)) dec] ["spicy" "prawns"]) => 19
(deftest apply-fn-chain-test
  (testing "apply-fn-chain"
    (is (= 4 (apply-fn-chain [] 4)))
    (is (= 12 (apply-fn-chain [inc inc (fn [x] (* x 2))] 4)))
    (is (= '((:c :b :a)) (apply-fn-chain [reverse list] [:a :b :c])))
    (is (= 19 (apply-fn-chain [count (fn [x] (* x 10)) dec] ["spicy" "prawns"])))
    ))



;;    (circus [:a :b :c] 0) => []
;;    (circus [:a :b :c] 1) => [[:a :b :c]]
;;    (circus [:a :b :c] 2) => [[:a :b :c] [:b :a :c]]
;;    (circus [:a :b :c] 3) => [[:a :b :c] [:b :a :c] [:b :c :a]]
(deftest circus-test
  (testing "circus"
    (is (= [] (circus [:a :b :c] 0)))
    (is (= [[:a :b :c]] (circus [:a :b :c] 1)))
    (is (= [[:a :b :c] [:b :a :c]] (circus [:a :b :c] 2)))
    (is (= [[:a :b :c] [:b :a :c] [:b :c :a]] (circus [:a :b :c] 3)))
    ))