(ns cs340-final.core-test
  (:require [clojure.test :refer :all]
            [cs340-final.core :refer :all]))

;    (swap-weird [[:ham] [[:beans]]]) => [[:beans] [[:ham]]]
;    (swap-weird [[4] [["ever"]]]) => [["ever"] [[4]]]
;    (swap-weird [[:xyzzy] [[:plugh]]]) => [[:plugh] [[:xyzzy]]]
(deftest swap-weird-test
  (testing "swap-weird"
    (is (= [[:beans] [[:ham]]] (swap-weird [[:ham] [[:beans]]])))
    (is (= [["ever"] [[4]]] (swap-weird [[4] [["ever"]]])))
    (is (= [[:plugh] [[:xyzzy]]] (swap-weird [[:xyzzy] [[:plugh]]])))
    ))

;;     (conjn [:a :b :c] 0 :d) => [:a :b :c]
;;     (conjn [:a :b :c] 3 :d) => [:a :b :c :d :d :d]
;;     (conjn '(2 3 4) 2 1) => (1 1 2 3 4)
(deftest conjn-test
  (testing "conjn"
    (is (= [:a :b :c] (conjn [:a :b :c] 0 :d)))
    (is (= [:a :b :c :d :d :d] (conjn [:a :b :c] 3 :d)))
    (is (= [:a :b :c :d :d :d :d :d] (conjn [:a :b :c] 5 :d)))
    (is (= '(1 1 2 3 4) (conjn '(2 3 4) 2 1)))
    ))

;;    (replicate-members [:a :b :c] 0) => []
;;    (replicate-members [:a :b :c] 1) => [:a :b :c]
;;    (replicate-members [:a :b :c] 2) => [:a :a :b :b :c :c]
;;    (replicate-members ["spam" "eggs" "baked beans"] 3)
;;       => ["spam"
;;           "spam"
;;           "spam"
;;           "eggs"
;;           "eggs"
;;           "eggs"
;;           "baked beans"
;;           "baked beans"
;;           "baked beans"]
;;
(deftest replicate-members-test
  (testing "replicate-members"
    (is (= [] (replicate-members [:a :b :c] 0)))
    (is (= [:a :b :c] (replicate-members [:a :b :c] 1)))
    (is (= [:a :a :b :b :c :c] (replicate-members [:a :b :c] 2)))
    (is (= ["spam"
            "spam"
            "spam"
            "eggs"
            "eggs"
            "eggs"
            "baked beans"
            "baked beans"
            "baked beans"] (replicate-members ["spam" "eggs" "baked beans"] 3)))
    ))

;;    (count-delimiters :a) => 0
;;    (count-delimiters [:a :b :c]) => 2
;;    (count-delimiters [[:a] [:b] :c]) => 6
;;    (count-delimiters [:a [:b :c '(:d :e [:f]) :g]]) => 8
(deftest count-delimiters-test
  (testing "count-delimiters"
    (is (= 0 (count-delimiters :a)))
    (is (= 2 (count-delimiters [])))
    (is (= 6 (count-delimiters [[:a] [:b] :c])))
    (is (= 8 (count-delimiters [:a [:b :c '(:d :e [:f]) :g]])))
    ))

