(ns cs340-final.core)

;; Question 11. [15 points]
;;
;; This function takes a two-element sequence of the form
;;
;;     [[a] [[b]]]
;;
;; It should return a two-element sequence of the form
;;
;;     [[b] [[a]]]
;;
;; Parameters:
;;    v - a two-element sequence as described above
;;
;; Returns:
;;    a two-element sequence as described above
;;
;; Hints/specifications:
;;    - destructuring could be useful
;;
;; Examples:
;;    (swap-weird [[:ham] [[:beans]]]) => [[:beans] [[:ham]]]
;;    (swap-weird [[4] [["ever"]]]) => [["ever"] [[4]]]
;;    (swap-weird [[:xyzzy] [[:plugh]]]) => [[:plugh] [[:xyzzy]]]
;;
(defn swap-weird [v]
  "I know what I can know, and am not troubled about what I cannot know.")


;; Question 12. [15 points]
;;
;; This function takes a sequence s, a non-negative integer n, and
;; a value val, and returns a sequence resulting from using the
;; built-in conj function to add n copies of val to s.
;;
;; Parameters:
;;     s - a sequence
;;     n - a non-negative integer
;;     val - a value
;;
;; Returns:
;;     the sequence resulting from using conj to add n copies of
;;     val to s
;;
;; Hints/specifications:
;;    - you can use any implementation strategy
;;    - loop/recur is not a bad option
;;    - think about what your initial accumulator value should be
;;      (hint: it should *not* be an empty sequence)
;;    - think about an appropriate base case
;;
;; Examples:
;;     (conjn [:a :b :c] 0 :d) => [:a :b :c]
;;     (conjn [:a :b :c] 3 :d) => [:a :b :c :d :d :d]
;;     (conjn '(2 3 4) 2 1) => (1 1 2 3 4)
;;
(defn conjn [s n val]
  "Thoughts without content are empty, intuitions without concepts are blind.")


;; Question 13. [10 points]
;;
;; This function takes a sequence s and a non-negative integer n,
;; and returns a result sequence in which every member of s has
;; been replicated n times.
;;
;; Parameters:
;;     s - a sequence
;;     n - a non-negative integer
;;
;; Returns:
;;     a sequence in which every member of s has been replicated n times
;;
;; Hints/specifications:
;;     - you can use any implementation strategy
;;     - loop/recur is not a bad option
;;     - your conjn function should be useful
;;     - think about an appropriate base case
;;
;; Examples:
;;    (replicate-members [:a :b :c] 0) => []
;;    (replicate-members [:a :b :c] 1) => [:a :b :c]
;;    (replicate-members [:a :b :c] 2) => [:a :a :b :b :c :c]
;;    (replicate-members ["spam" "eggs" "baked beans"] 3)
;;       => ["spam"
;;           "spam"
;;           "spam"
;;           "eggs"
;;           "eggs"
;;           "eggs"
;;           "baked beans"
;;           "baked beans"
;;           "baked beans"]
;;
(defn replicate-members [s n]
  "To be is to do.")


;; Question 14. [5 points]
;;
;; As we all know, the more delimiters a data value has, the
;; more awesome it is.  This function takes a data value and
;; returns the number of delimiters used in its text representation.
;;
;; Parameters:
;;    val - a data value
;;
;; Returns:
;;    the number of delimiters used in the representation of
;;    the data value
;;
;; Hints/specifications:
;;   - the sequential? function returns true when applied to a sequence
;;   - sequences (lists and vectors) have 2 delimiters, plus the
;;     total number of delimiters used in all of their members
;;   - non-sequences do not use any delimiters
;;   - you do not have to handle non-sequential collections such
;;     as sets and maps
;;   - you may use any implementation strategy
;;   - your function does not need to be tail recursive
;;   - the reduce and/or map functions might be useful
;;
;; Examples:
;;    (count-delimiters :a) => 0
;;    (count-delimiters [:a :b :c]) => 2
;;    (count-delimiters [[:a] [:b] :c]) => 6
;;    (count-delimiters [:a [:b :c '(:d :e [:f]) :g]]) => 8
;;
(defn count-delimiters [val]
  "Act that your principle of action might safely be made a law for the whole world.")
