# cs340-lab12

A Clojure library designed to ... well, that part is up to you.

## Usage

FIXME

## License

Copyright © 2016 FIXME

Distributed under the Eclipse Public License either version 1.0 or (at
your option) any later version.
